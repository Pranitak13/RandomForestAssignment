
# importing the necessary dependencies
from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin
import pandas as pd
import pickle
import numpy as np
from sklearn import datasets
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import RandomizedSearchCV
from sklearn.preprocessing import StandardScaler


application = Flask(__name__) # initializing a flask app

filename = 'modelForPrediction.sav'
rand_clf2 = pickle.load(open(filename, 'rb'))  # loading the model file from the storage
# predictions using the loaded model file

boston = datasets.load_boston()
bos = pd.DataFrame(boston.data)
bos.columns = (boston.feature_names)
bos["Price"] = boston.target
X = bos.drop(columns = 'Price')

@application.route('/')  # route to display the home page
@cross_origin()
def homePage():
    return render_template('index.html')

@application.route('/predict',methods=['POST']) # route to show the predictions in a web UI
@cross_origin()
def predict():
    '''
    For rendering results on HTML GUI
    '''
    float_features = [float(x) for x in request.form.values()]
    final_features = [np.array(float_features)]

    prediction = rand_clf2.predict(final_features)
    print('prediction is', prediction)

    return render_template('results.html',prediction=(100*prediction))
if __name__ == "__main__":
    application.run(host='127.0.0.1', port=8001, debug=True)
	#app.run(debug=True) # running the app